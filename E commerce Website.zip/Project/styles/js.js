<html>  
   <head>     
      <script type = "text/javascript">  
            function fun() {  
                prompt("This is a prompt box ");  
            }  
      </script>       
   </head>  
     
   <body>  
      <p> Click</p>        
      <form>  
         <input type = "button" value = "Click me" onclick = "fun();" />  
      </form>       
   </body>  
</html>  
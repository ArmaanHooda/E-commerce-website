window.alert("Email Confirmation Number Has Been Sent To Your Email");

function myFunction() {
    var str = "Confirmation Number has been sent again!";
    var result = str.blink();
    document.getElementById("demo").innerHTML = result;
}


function checkFormEntry ()
{     
 window.location.href="buythanks.html";
	
		
	
	return false;
}

document.getElementById("contact1").onsubmit=checkFormEntry;	